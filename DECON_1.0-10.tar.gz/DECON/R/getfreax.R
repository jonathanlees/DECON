getfreax <-
function(klog = c(-4, -3,-2,-1,0, 1, 2), len=1000)
    {
#### klog are powers of 10 used to create detailed frequency scale
####  used to make sure that plotting on a x-log scale there are
#### enough points to make a nice plot
        i = 1

        f1 = 10^(klog[i])
        f2 = 10^(klog[i+1])
        eff = seq(from=f1, to=f2, length=len)
        f.out = eff


        for(i in 2:(length(klog)-1))
            {

                f1 = 10^(klog[i])
                f2 = 10^(klog[i+1])
                eff = seq(from=f1, to=f2, length=len)

                f.out = c(f.out, eff)
###  lines(eff, g$M)
            }
        return(f.out)
    }
