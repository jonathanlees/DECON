setEvent<-function(events, k = NA)
    {
        ###    require(lubridate)
        anss = vector(mode='list')
        i = 1

        ptime = RSEIS::posix2RSEIS(events$time)

        if(is.na(k) ) {
            iget = 1:length(ptime$sec)
            for(i in iget  )
                {
                    k = i
                    anss$yr[i] = ptime$yr[k]
                    anss$mo[i] = ptime$mo[k]
                    anss$dom[i] = ptime$dom[k]
                    anss$jd[i] = RSEIS::getjul(ptime$yr[k],ptime$mo[k], ptime$dom[k])
                    anss$hr[i] = ptime$hr[k]
                    anss$mi[i] = ptime$mi[k]
                    anss$sec[i] =   ptime$sec[k]
                    anss$lat[i] =   events$latitude[k]
                    anss$lon[i] =   events$longitude[k]
                    anss$LON[i] =   RPMG::fmod( events$longitude[k] , 360)
                    anss$mag[i] =   events$magnitude[k]
                    anss$z[i] =     events$depth[k]
                    anss$depth[i] = events$depth[k]
                    anss$LocInfo[i] = events$eventLocationName[k]
                    
                }
        }
        else
            {
                i = 1
                    anss$yr[i] = ptime$yr[k]
                    anss$mo[i] = ptime$mo[k]
                    anss$dom[i] = ptime$dom[k]
                    anss$jd[i] = RSEIS::getjul(ptime$yr[k],ptime$mo[k], ptime$dom[k])
                    anss$hr[i] = ptime$hr[k]
                    anss$mi[i] = ptime$mi[k]
                    anss$sec[i] =   ptime$sec[k]
                    anss$lat[i] =   events$latitude[k]
                    anss$lon[i] =   events$longitude[k]
                    anss$LON[i] =   RPMG::fmod( events$longitude[k] , 360)
                    anss$mag[i] =   events$magnitude[k]
                    anss$z[i] =     events$depth[k]
                anss$depth[i] = events$depth[k]
                anss$LocInfo[i] = events$eventLocationName[k]
            }
        
   
       

   
   return(anss)
    }
