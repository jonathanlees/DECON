checkNORM <-
function(paz, EFF=1 )
{
########  calculate the normalization factor for deconvolution
######  this is done at a specific frequency in flat pass band (e.g. 1 Hz)
    paz.knorm = paz2transfer(paz, EFF=EFF)
    Knorm = 1/Mod(paz.knorm$H)
    ## message(Knorm)
    return(Knorm)
}
