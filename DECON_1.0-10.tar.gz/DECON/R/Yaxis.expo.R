Yaxis.expo  <-function(yt, yat, cex=0.8,  cex.exp=1, adj=c(1,-1) )
    {
####   ?plotmath
###yt = the numbers (labels)
##### yat = the y-locations where to plot them
     #####   require(graphics)
        
        mantissa <- function(x) {
            if (x == 0) return(0)
            else {
                log <- log10(abs(x))
                return(10^(log - floor(log)))
            }
        }
        
        exponent <- function(x) {
            if (x == 0) 0
            else floor(log10(abs(x)))
        }
        upar = par('usr')
        
        myt = vector(length=length(yt) )
        eyt = vector(length=length(yt) )
        syt = sign(yt)
        for(i in 1:length(yt) ) { myt[i] = mantissa(yt[i] ) }
        for(i in 1:length(yt) ) { eyt[i] = exponent(yt[i] ) }
        
        ### check to see if the mantissa needs to be adjusted:
        
        ge = eyt[eyt!=0]
            
        myt = myt*syt 
        
        ###   ex = seq(from=0, by=F58$dt[3], length=length(amp) )
            
       ##  plot(ex, amp, type='l', axes=FALSE)
          
        axis(2, tck=-0.005 , at=yat, labels=FALSE, las=2 , line=0.1 )
        
       ###  axis(2, tck=-0.005 , pos=upar[1] , at=yt, labels=myt, las=2 , line=0.1 )
        
        text(x=upar[1], y = yat, labels=myt, pos=2, xpd=TRUE, cex=cex )
        
        n = length(yt) 
        
        ktext = strwidth('X10', units = "user")

        text(x=upar[1], y = yat[n], labels=substitute( ''%*%10^i, list(i=eyt[n])),
             adj=adj ,
             xpd=TRUE, cex=cex.exp  )

        
    }
  
        
        
