paz2text<-function(paz)
    {
#######  format from old SAC code:
        Tresp = vector(mode='character', length=4+paz$nz+paz$np)

        j = 1
        Tresp[j] = paste("ZEROS", paz$nz)
        for(i in 1:paz$nz )
            {
                p = paste(Re(paz$zeros[i]), Im(paz$zeros[i]))
                j = j+1
                Tresp[j] = p

            }

        
        j = j+1
        Tresp[j] = paste("POLES", paz$np)
        for(i in 1:paz$np )
            {
                p = paste(Re(paz$poles[i]), Im(paz$poles[i]))
                j = j+1
                Tresp[j] = p

            }
        j = j+1
        Tresp[j] = paste("CONSTANT", paz$Knorm)
        j = j+1
        Tresp[j] = paste("SENSE", paz$Sense)

        return(Tresp)

    }
