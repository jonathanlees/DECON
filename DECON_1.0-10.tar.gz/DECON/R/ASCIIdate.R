ASCIIdate<-function(J)
    {
############  given data-time structure from RSEIS, return ascii
#### good only to the second
        dat1 = paste(formatC(J$yr, width = 4),
            formatC(J$mo, width = 2, flag = 0),
            formatC(J$dom, width = 2, flag = 0), 
            sep = "-")

        tim1 = paste(formatC(J$hr, width = 2, flag = 0),
            formatC(J$mi,  width = 2, flag = 0),
            formatC(J$sec, width = 2, flag = 0), 
            sep = ":")

        pb.txt = paste(dat1, tim1, sep=' ')

        return(pb.txt)
    }
