better.decon<-function(data, dt = dt, paz, waterlevel = 1e-08, pcttap=0.05, sense=TRUE )
    {
############  to achieve a better result, first remove mean, detrend, taper data
#####  for a better decon result, perform some pre- post- transforms
        ###  default is 5 percent taper
        y = RSEIS::detrend(data)
        y = RSEIS::applytaper(y, p = pcttap)
        dy = paz.decon( y, dt = dt, paz, waterlevel = waterlevel, sense=sense )
        ty = RSEIS::applytaper(dy - mean(dy), p = pcttap)
        tapy = RSEIS::detrend(ty)
        fy1 = tapy - mean(tapy)
        return(fy1)
    }
